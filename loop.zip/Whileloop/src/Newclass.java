
public class Newclass {
	public static void main(String[] args) {
	
 int x = 7;

    while (x<15) 
    {
	      System.out.println(x);
	      x++;
	}
    

   {       
	System.out.println("Loop ended");
	
   }
}	

}	
	
		

	


